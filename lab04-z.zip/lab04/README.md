## Database
Database name: lab04_jenna
Table 1 (parent): customers
Table 2 (child): orders
Primary key (Table 1):
Foreign key (Table 2):
## Data
Rows in Table 1: 3
Rows in Table 2: 3
## JOIN query I ran
```sql
-- paste your JOIN query here
