# Lab 06 — PHP Web Security & Sessions (Secure Notes)
**Student Name:**
**Date:**
## 1) What I built (1–2 sentences)
I learned how to build a web security session with php and learned about login sessions, like access, security, control, and hardening. I feel I better understand how php and myadmin work together.
## 2) How to run my lab
**Database name:** `lab06_jenna'
**Start page URL:** http://localhost/winter3363/lab06/public/index.php
Steps:
1. Start XAMPP (Apache + MySQL)
2. Open phpMyAdmin and create my database
3. Run the Lab06 SQL to create tables: `users`, `notes`
4. Update `app/db.php` with my DB name
5. Open the start page URL above
## 3) Security features checklist:
## 4) Test Results (PASS/FAIL)
- Register works: _PASS_
- Login works (correct password): _PASS_
- Login fails (wrong password): _PASS_
- Dashboard redirects when logged out: _PASS_
- Create note works: _PASS_
- XSS test does NOT run (`<script>alert('xss')</script>`): _PASS_
- Admin page (user gets 403): _PASS_
- Admin page (admin can view): _PASS_
- Session timeout works: _PASS_
## 5) Reflection: what I have learned from Lab 06 (3-5 sentences)
 I feel I better understand how php and myadmin work together and how each page or file you create are important for the site to function properly. I do feel like I have a better grasp of what the steps would be when makeing a website from scratch that people other than just myself can interact with. I am glad we are learning about how to implement security features into our websites.