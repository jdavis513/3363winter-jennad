<?php
declare(strict_types=1);
require_once __DIR__ . "/../app/security.php";
require_once __DIR__ . "/../app/db.php";
require_once __DIR__ . "/../app/auth.php";
security_headers();
$errors = [];
$timeout_msg = "";
if (isset($_GET["timeout"])) {
 $timeout_msg = "Your session expired due to inactivity. Please login again.";
}
if ($_SERVER["REQUEST_METHOD"] === "POST") {
 $email = clean_string($_POST["email"] ?? "");
 $password = $_POST["password"] ?? "";
 if ($email === "" || $password === "") {
 $errors[] = "Email and password are required.";
 } else {
 // STUDENT TODO: Fetch user by email using prepared statement
 $stmt = $pdo->prepare("SELECT id, email, password_hash, role FROM users WHERE
email = ?");
 $stmt->execute([$email]);
 $user = $stmt->fetch();
 // STUDENT TODO: Verify password with password_verify
 if ($user && password_verify($password, $user["password_hash"])) {
 on_login_success((int)$user["id"], $user["email"], $user["role"]);
 header("Location: dashboard.php");
 exit;
 } else {
 $errors[] = "Invalid login.";
 }
 }
}
?>
<!doctype html>
<html lang="en">
<head>
 <meta charset="utf-8">
 <title>Login</title>
 <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="wrapper">
    <h1>Login</h1>
 <?php if ($timeout_msg): ?>
    <p><?= e($timeout_msg) ?></p>
 <?php endif; ?>
 <?php if ($errors): ?>
    <ul>
 <?php foreach ($errors as $err): ?>
 <li><?= e($err) ?></li>
  <?php endforeach; ?>
 </ul>
 <?php endif; ?>
 <form method="post" novalidate>
 <label>Email:
 <input type="email" name="email" required>
 </label>
 <br><br>
 <label>Password:
 <input type="password" name="password" required>
 </label>
 <br><br>
 <button type="submit">Login</button>
 </form>
 <p><a href="register.php">Create an account</a></p>
 </div>
</body>
</html>