<?php
declare(strict_types=1);
require_once __DIR__ . "/../app/security.php";
require_once __DIR__ . "/../app/db.php";
require_once __DIR__ . "/../app/auth.php";
security_headers();
enforce_session_timeout();
require_login();
$user_id = (int)($_SESSION["user_id"] ?? 0);
$email = $_SESSION["email"] ?? "User";
// STUDENT TODO: Fetch only this user's notes (prepared statement)
$stmt = $pdo->prepare("SELECT id, title, content, created_at FROM notes WHERE user_id
= ? ORDER BY id DESC");
$stmt->execute([$user_id]);
$notes = $stmt->fetchAll();
?>
<!doctype html>
<html lang="en">
<head>
 <meta charset="utf-8">
 <title>Dashboard</title>
 <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="wrapper">
    <h1>Dashboard</h1>
 <p>Welcome, <?= e($email) ?></p>
 <p>
 <a href="create_note.php">Create Note</a> |
 <a href="admin.php">Admin Page</a> |
 <a href="logout.php">Logout</a>
 </p>
 <h2>Your Notes</h2>
 <!-- STUDENT TODO (XSS test): Create a note containing
<script>alert('xss')</script> and confirm it does NOT run. -->
 <?php if (!$notes): ?>
 <p>No notes yet.</p>
 <?php else: ?>
 <ul>
 <?php foreach ($notes as $n): ?>
 <li>
 <strong><?= e($n["title"]) ?></strong>
 <div><?= nl2br(e($n["content"])) ?></div>
 <small><?= e($n["created_at"]) ?></small>
 </li>
 <?php endforeach; ?>
 </ul>
 <?php endif; ?>
 </div>
</body>
</html>