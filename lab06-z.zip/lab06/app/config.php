<?php
declare(strict_types=1);
// Timezone for this course (Halifax). Do not change unless instructed.
date_default_timezone_set("America/Halifax");
define("SESSION_TIMEOUT", value: 600);
// Security: session cookies
ini_set("session.use_strict_mode", "1");
ini_set("session.cookie_httponly", "1");
ini_set("session.cookie_secure", "0");
// Lax is OK for this lab. In production you may choose Strict.
ini_set("session.cookie_samesite", "Lax");
// Start session
session_start();