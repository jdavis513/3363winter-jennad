<?php
/*
 Lab 05 - PDO Database Connection (PDO + prepared statements)
 STUDENT TODO:
 1) Change $db_name to your database name (lab05_yourfirstname)
 2) If your MySQL user/pass differs, update $db_user / $db_pass
*/
$db_host = "localhost";
$db_lab05_name = "lab05_jenna"; // STUDENT TODO: change to lab05_yourfirstname
$db_user = "root"; // usually root in XAMPP
$db_pass = ""; // usually blank in XAMPP
$dsn = "mysql:host={$db_host};dbname={$db_lab05_name};charset=utf8mb4";
$options = [
 PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
 PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
 PDO::ATTR_EMULATE_PREPARES => false
];
try {
 $pdo = new PDO($dsn, $db_user, $db_pass, $options);
} catch (PDOException $e) {
 // In production, do not show full error details.
 die("Database connection failed. STUDENT: check db name/user/pass. Error: " . $e->getMessage());
}