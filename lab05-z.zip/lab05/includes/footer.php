<?php
?>
 <hr />
 <p class="muted">Lab 05 - PDO CRUD (XAMPP Localhost). + Jenna Davis 2026</p> <!-- add your first and last
name +2026 -->
 </div>
</body>
</html>
