<!DOCTYPE html>
<html lang="en">
<head>
 <meta charset="UTF-8" />
 <meta name="viewport" content="width=device-width, initial-scale=1.0" />
 <title>Lab 02 - Dynamic PHP + CSS</title>
 <link rel="stylesheet" href="styles.css" />
</head>
<body>
 <?php
 $firstName = "Jenna";
 $lastName = "Davis";
 date_default_timezone_set("America/Halifax");
 $now = date("Y-m-d g:i A");
 ?>
 <div class="container">
 <h1>Dynamic PHP Page (Lab 02)</h1>
 <p class="badge">Student: <?php echo $firstName . " " . $lastName; ?></p>
 <p>Current date and time:</p>
 <p class="time"><?php echo $now; ?></p>
 <p>What you practiced:</p>
 <ul>
 <li>PHP variables</li>
 <li>PHP echo output inside HTML</li>
 <li>date() and timezone</li>
 <li>External CSS styling</li>
 </ul>
  </div>
</body>
</html>