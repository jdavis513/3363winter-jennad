# Lab 07 — Validation & Error Handling (JavaScript + PHP)
**Student Name:** _Jena Davis______
**Submission Date:** _March_2_2026___________
## 1) How to Run
1. Start **Apache** in XAMPP.
2. Put this folder in: `C:\xampp\htdocs\winter3363\lab07_jenna\lab07\`
3. Testing URL:
http://inte3363winter2026.webcoursespace.com/students/jdavis/winter3363/labs/lab07/ 
## 2) Files Included (check)
- [ ] `index.php`
- [ ] `process.php`
- [ ] `includes/helpers.php`
- [ ] `assets/validation.js`
- [ ] `assets/style.css`
- [ ] `data/submissions.jsonl`
- [ ] `logs/errors.log`
---
## 3) Validation Completed (check)
### JavaScript (client-side)
- [ ] Required fields blocked
- [ ] Email format checked
- [ ] Course code format checked (INTE####)
- [ ] Rating checked (1–5)
- [ ] Agree checkbox required
- [ ] Errors show beside fields
- [ ] Prevent submit when invalid
### PHP (server-side)
- [ ] Validates the same rules again
- [ ] Shows errors beside fields
- [ ] Keeps sticky values (old input stays)
- [ ] Uses `try/catch` for saving file
- [ ] Logs errors to `logs/errors.log`
---
## 4) Testing Checklist (Required)
Fill in Pass/Fail.
| Test | Pass/Fail |
|------|----------|
| Empty submit shows errors | ___ |
| Invalid email blocked | ___ |
| Invalid course code blocked | ___ |
| Rating out of range blocked | ___ |
| Agree unchecked blocked | ___ |
| Disable JS (comment out script tag) → PHP still blocks invalid data | ___ |
| Valid submit saves to `submissions.jsonl` | ___ |
---
## 5) Compare JavaScript vs PHP Validation (What I learned)
Fill in 1–2 sentences for each.
**JavaScript validation is good for:**
__Providing instant feedback without having to reload the page.________
**JavaScript validation is NOT reliable for security because:**
__It is wholely in the browser where it can be bypassed into.____________
**PHP validation is important because:**
__It runs on the server side that way the user has no access to it.____________
**One example from my testing (disable JS) that proved PHP is needed because:**
__When Javascript was disabled the form skipped pass all the checks on the users side. Php catches all the individual errors and prevents bad data from going through. __